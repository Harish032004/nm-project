export interface IUserUpdateProfile{
    name: string;
    address: string;
}